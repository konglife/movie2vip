import xbmcaddon

MainBase = 'https://movie2vip.ga/kodi/plugin.video.movie2vip/home.txt'
addon = xbmcaddon.Addon('plugin.video.movie2vip')